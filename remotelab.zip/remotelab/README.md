# Remote Lab - Virtual Electronics Laboratory

A simple web-based remote laboratory for electronics development with real-time video streaming, audio monitoring, and microcontroller communication.

## 🚀 Quick Setup

### For PC/Ubuntu Desktop:
```bash
./setup.sh
python3 app.py
```

### For Raspberry Pi:
```bash
./raspberrypi-setup.sh
# App starts automatically on boot!
```

Access at: `http://localhost:5000` or `http://raspberrypi.local:5000`

## ✨ Features

- **Real-time video streaming** (works without audio)
- **Serial communication** with Arduino/ESP32/AVR
- **Firmware upload** for microcontrollers
- **Independent controls** - audio/video/serial can run separately
- **Mobile responsive** web interface

## 📋 Requirements

**Hardware:**
- Webcam (optional)
- Microphone (optional)
- Arduino/ESP32/AVR boards

**Software:**
- Python 3.7+
- Linux/Ubuntu

## 🛠️ Installation

### Option 1: Automated Setup (Recommended)
```bash
# For PC/Desktop
./setup.sh

# For Raspberry Pi
./raspberrypi-setup.sh
```

### Option 2: Manual Setup
```bash
# Install system tools
sudo apt install python3 python3-pip avrdude esptool

# Install Python packages (handle externally managed environment)
pip3 install --break-system-packages -r requirements.txt

# Alternative if you prefer not to break system packages:
# sudo apt install python3-pyaudio python3-opencv
# pip3 install flask flask-socketio pyserial python-socketio numpy werkzeug

# Set permissions
sudo usermod -a -G dialout,video,audio,plugdev $USER
```

## 🎯 Usage

### Manual Start
```bash
python3 app.py
```

### Automatic Start (Raspberry Pi)
```bash
# Start service
sudo systemctl start remotelab

# Check status
sudo systemctl status remotelab

# View logs
sudo journalctl -u remotelab -f
```

**Access:** `http://localhost:5000` or `http://raspberrypi.local:5000`

**Features:**
1. **Video**: Click "Start Video" (optional)
2. **Audio**: Click "Start Audio" (optional)
3. **Serial**: Select device, set baud rate, click "Start Serial Monitor"

## 🔧 Audio Without Video

**Yes! Audio works independently:**
- ✅ Audio monitoring without video streaming
- ✅ Serial communication without video
- ✅ Firmware upload without video
- ✅ All features work with audio only

## 📁 Project Structure

```
remotelab/
├── app.py              # Main application
├── setup.sh           # PC setup script
├── raspberrypi-setup.sh # Raspberry Pi setup script
├── requirements.txt   # Python dependencies
├── remotelab.service  # Systemd service (optional)
└── templates/
    └── index.html     # Web interface
```

## 🔍 Troubleshooting

### Externally Managed Environment Issues

**If you get "externally managed environment" errors:**

**Option 1: Use --break-system-packages (Recommended for this project)**
```bash
pip3 install --break-system-packages -r requirements.txt
```

**Option 2: Install system packages instead**
```bash
# Install core system packages
sudo apt install python3-pyaudio python3-opencv

# Install remaining packages normally
pip3 install flask flask-socketio pyserial python-socketio numpy werkzeug
```

**Option 3: Use virtual environment**
```bash
python3 -m venv venv
source venv/bin/activate
pip3 install -r requirements.txt
# Run with: source venv/bin/activate && python3 app.py
```

### Raspberry Pi Installation Issues

**If you have conflicts or used --break-system-packages:**

```bash
# Clean up everything first
./cleanup-rpi.sh

# Then do fresh install
./raspberrypi-setup.sh

# Test if everything works
./test-installation.sh
```

**Service file conflicts:**
```bash
# Check for conflicting services
systemctl list-units | grep remote

# Remove conflicting services
sudo systemctl disable [service-name]
sudo systemctl stop [service-name]
sudo rm /etc/systemd/system/[service-file]
sudo systemctl daemon-reload
```

### Hardware Issues

**Camera not working:**
```bash
ls /dev/video*
v4l2-ctl --list-devices
# For Raspberry Pi camera: sudo raspi-config → Interfacing Options → Camera
```

**Serial not working:**
```bash
ls /dev/ttyUSB* /dev/ttyACM*
groups $USER
sudo usermod -a -G dialout $USER
```

**Audio not working:**
```bash
python3 -c "import pyaudio; print('Audio OK')"
sudo apt install python3-pyaudio
# Check audio devices: python3 -c "import pyaudio; p=pyaudio.PyAudio(); [print(i, p.get_device_info_by_index(i)) for i in range(p.get_device_count())]; p.terminate()"
```

**Permission issues:**
```bash
sudo usermod -a -G dialout,video,audio,plugdev $USER
# Log out and back in for permissions to take effect
```

### Application Issues

**Port already in use:**
```bash
sudo lsof -i :5000
sudo kill -9 [PID]
```

**Import errors:**
```bash
pip3 install -r requirements.txt
# Or for Raspberry Pi: sudo apt install python3-pyaudio python3-opencv
```

**Service not starting:**
```bash
# Check service status
sudo systemctl status remotelab

# View service logs
sudo journalctl -u remotelab --no-pager

# Check if service is enabled
sudo systemctl is-enabled remotelab

# Manual start for testing
python3 app.py
```

**Service already running:**
```bash
# Stop service
sudo systemctl stop remotelab

# Disable auto-start
sudo systemctl disable remotelab

# Manual control
python3 app.py
```
