
import pyvisa

def test_visa():
    """
    Tests the pyvisa installation and lists available resources.
    """
    print("Attempting to initialize PyVISA...")
    try:
        # Explicitly use the pyvisa-py backend
        rm = pyvisa.ResourceManager('@py')
        print("PyVISA Resource Manager initialized successfully with pyvisa-py backend.")

        print("\nListing available VISA resources...")
        resources = rm.list_resources()

        if not resources:
            print("--------------------------------------------------")
            print("-> NO VISA resources found.")
            print("-> This is likely the cause of the issue.")
            print("-> Please ensure libusb is installed (`sudo apt-get install libusb-1.0-0`)")
            print("-> and that your oscilloscope is connected and powered on.")
            print("--------------------------------------------------")
        else:
            print("--------------------------------------------------")
            print("-> Found the following VISA resources:")
            for i, resource in enumerate(resources):
                print(f"  {i}: {resource}")
            print("--------------------------------------------------")
            print("-> SUCCESS: Your environment can see the oscilloscope.")
            print("-> The problem is likely within the web application's logic.")

        # Optional: Try to open the first found resource
        if resources:
            try:
                print(f"\nAttempting to open resource: {resources[0]}")
                instrument = rm.open_resource(resources[0])
                idn = instrument.query('*IDN?')
                print(f"-> Successfully opened and identified instrument: {idn.strip()}")
                instrument.close()
            except pyvisa.errors.VisaIOError as e:
                print(f"-> ERROR: Could open the resource, but failed to communicate.")
                print(f"-> This might be a permissions issue or an SCPI command mismatch.")
                print(f"-> Error details: {e}")

    except Exception as e:
        print("\n--------------------------------------------------")
        print(f"-> An unexpected error occurred: {e}")
        print("-> This could indicate a problem with your PyVISA installation or backend.")
        print("--------------------------------------------------")

if __name__ == "__main__":
    test_visa()

