from flask import Flask, render_template, request, jsonify, redirect, url_for, Response
from flask_socketio import SocketIO, emit
import os
import subprocess
import serial.tools.list_ports
import threading
import time
import json
import socket
from werkzeug.utils import secure_filename
import cv2
try:
    import pyaudio
    PYAUDIO_AVAILABLE = True
except ImportError:
    PYAUDIO_AVAILABLE = False
    print("PyAudio not available - audio features will be disabled")
import numpy as np
import base64
import io
try:
    import RPi.GPIO as GPIO
    GPIO_AVAILABLE = True
except ImportError:
    GPIO_AVAILABLE = False
    print("RPi.GPIO not available - PWM features will be disabled")

try:
    import pyvisa
    VISA_AVAILABLE = True
except ImportError:
    VISA_AVAILABLE = False
    print("PyVISA not available - oscilloscope features will be disabled")

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = '.'
app.config['ALLOWED_EXTENSIONS'] = {'hex', 'bin'}
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Initialize SocketIO
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Global variables for video and audio streaming
video_capture = None
audio_stream = None
serial_connection = None
video_streaming_active = False
audio_streaming_active = False
serial_monitoring_active = False

# Legacy variables (kept for compatibility)
serial_process = None
video_process = None

# Device configurations
ARDUINO_IDS = {'2341', '2a03', '1a86'}
ESP32_IDS = {'10c4', '303a'}
USBASP_IDS={'16c0:05dc'}
ESP_BAUD = "460800"

# Global variables for terminal output
terminal_output = []
upload_in_progress = False

# Device detection cache
device_cache = []
device_cache_time = 0
DEVICE_CACHE_TIMEOUT = 30  # Cache devices for 30 seconds

# Oscilloscope variables (using pyVISA for USB oscilloscopes)
oscilloscope_data = []
oscilloscope_buffer_size = 1000
oscilloscope_resource = None  # pyVISA resource for oscilloscope
visa_available = False
oscilloscope_connected = False

# Oscilloscope settings
oscilloscope_timebase = 0.001  # 1ms/div (default)
oscilloscope_vscale = 1.0      # 1V/div (default)
oscilloscope_trigger_level = 0.0  # Trigger level
oscilloscope_channel = 1       # Active channel

def initialize_video_capture():
    """Initialize video capture from webcam"""
    global video_capture
    try:
        video_capture = cv2.VideoCapture(0)  # Use default camera
        if not video_capture.isOpened():
            print("Could not open video capture")
            return False
        # Set resolution to 480p (854x480) and 25 FPS
        video_capture.set(cv2.CAP_PROP_FRAME_WIDTH, 854)
        video_capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        video_capture.set(cv2.CAP_PROP_FPS, 25)
        return True
    except Exception as e:
        print(f"Error initializing video capture: {e}")
        return False

def check_audio_devices():
    """Check if physical audio input devices are available and actually working"""
    if not PYAUDIO_AVAILABLE:
        print("PyAudio not available - audio features disabled")
        return False, []

    try:
        audio = pyaudio.PyAudio()
        working_devices = []

        for i in range(audio.get_device_count()):
            try:
                device_info = audio.get_device_info_by_index(i)
                device_name = device_info.get('name', 'Unknown').lower()

                # Skip virtual devices that aren't real microphones
                if any(skip_name in device_name for skip_name in ['pipewire', 'pulse', 'null', 'default', 'dummy']):
                    print(f"Skipping virtual device: {device_info.get('name', 'Unknown')} (Index: {i})")
                    continue

                if device_info.get('maxInputChannels') > 0:
                    # Test if device actually works by trying to read data
                    try:
                        test_stream = audio.open(
                            format=pyaudio.paInt16,
                            channels=1,
                            rate=44100,
                            input=True,
                            input_device_index=i,
                            frames_per_buffer=1024
                        )

                        # Try to read a small amount of data to verify device works
                        test_data = test_stream.read(1024, exception_on_overflow=False)
                        test_stream.close()

                        # Check if we got actual audio data (not just silence)
                        if test_data and len(test_data) > 0:
                            # Convert to numpy array to check for actual audio content
                            audio_array = np.frombuffer(test_data, dtype=np.int16)
                            # Check if there's any non-zero audio data (not just silence)
                            if np.any(audio_array != 0):
                                working_devices.append(device_info)
                                print(f"Found working physical audio device: {device_info.get('name', 'Unknown')} (Index: {i})")
                            else:
                                print(f"Device {device_info.get('name', 'Unknown')} (Index: {i}) returned only silence")
                        else:
                            print(f"Device {device_info.get('name', 'Unknown')} (Index: {i}) returned no data")

                    except Exception as e:
                        print(f"Device {device_info.get('name', 'Unknown')} (Index: {i}) not accessible: {e}")
                        continue

            except Exception as e:
                print(f"Error checking device {i}: {e}")
                continue

        audio.terminate()

        if len(working_devices) == 0:
            print("No physical audio input devices found - audio will not be available")

        return len(working_devices) > 0, working_devices
    except Exception as e:
        print(f"Error checking audio devices: {e}")
        return False, []

def initialize_audio_stream():
    """Initialize audio capture"""
    global audio_stream

    if not PYAUDIO_AVAILABLE:
        print("PyAudio not available - cannot initialize audio")
        return False

    # First check if audio devices are available
    devices_available, device_list = check_audio_devices()
    if not devices_available:
        print("No audio input devices found - audio will not be available")
        return False

    try:
        audio = pyaudio.PyAudio()

        # Try to find a working input device
        input_device_index = None
        for device in device_list:
            try:
                # Test if we can open this device
                test_stream = audio.open(
                    format=pyaudio.paInt16,
                    channels=1,
                    rate=44100,
                    input=True,
                    input_device_index=int(device['index']),
                    frames_per_buffer=1024
                )
                test_stream.close()
                input_device_index = int(device['index'])
                print(f"Found working audio device: {device['name']} at index {input_device_index}")
                break
            except Exception as e:
                print(f"Device {device['name']} not available: {e}")
                continue

        if input_device_index is None:
            print("No working audio input device found")
            audio.terminate()
            return False

        # Use optimized settings for cleaner audio - ensure consistent sample rate
        SAMPLE_RATE = 48000  # Use 48kHz for better quality and compatibility
        audio_stream = audio.open(
            format=pyaudio.paInt16,
            channels=1,
            rate=SAMPLE_RATE,  # Consistent sample rate throughout pipeline
            input=True,
            input_device_index=input_device_index,
            frames_per_buffer=2048  # Larger buffer for better stability
        )
        print(f"Audio stream initialized at {SAMPLE_RATE}Hz")
        print("Audio stream initialized successfully")
        return True
    except Exception as e:
        print(f"Error initializing audio stream: {e}")
        # Make sure to clean up any partial audio objects
        try:
            if 'audio' in locals():
                audio.terminate()
        except:
            pass
        return False

def initialize_serial_connection(port, baudrate=9600):
    """Initialize serial connection for monitoring"""
    global serial_connection
    try:
        import serial
        serial_connection = serial.Serial(port, baudrate, timeout=1)
        # Flush any existing data in the buffer to prevent duplicate readings
        serial_connection.reset_input_buffer()
        return True
    except Exception as e:
        print(f"Error initializing serial connection: {e}")
        return False

def video_stream_thread():
    """Thread for video streaming - optimized for performance"""
    global video_capture, video_streaming_active

    if not video_capture or not video_capture.isOpened():
        print("Video capture not available - exiting video thread")
        return

    consecutive_errors = 0
    max_consecutive_errors = 5
    frame_interval = 1.0 / 15.0  # Target 15 FPS for better performance
    last_frame_time = time.time()

    print("Video streaming thread started")

    while video_streaming_active and video_capture and video_capture.isOpened():
        try:
            current_time = time.time()
            if current_time - last_frame_time < frame_interval:
                time.sleep(0.01)  # Small sleep to prevent busy waiting
                continue

            ret, frame = video_capture.read()
            if ret and frame is not None:
                # Encode frame as JPEG with optimized quality
                ret, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 75, cv2.IMWRITE_JPEG_OPTIMIZE, 1])
                if ret:
                    # Convert to base64 for transmission
                    frame_base64 = base64.b64encode(buffer).decode('utf-8')
                    socketio.emit('video_frame', {'frame': frame_base64})
                    consecutive_errors = 0
                    last_frame_time = current_time
                else:
                    consecutive_errors += 1
            else:
                consecutive_errors += 1
                print(f"Failed to read video frame (#{consecutive_errors})")

            if consecutive_errors >= max_consecutive_errors:
                print("Too many consecutive video errors, stopping video thread")
                video_streaming_active = False
                break

        except Exception as e:
            consecutive_errors += 1
            print(f"Error in video stream (#{consecutive_errors}): {e}")
            if consecutive_errors >= max_consecutive_errors:
                print("Too many consecutive video errors, stopping video thread")
                video_streaming_active = False
                break
            time.sleep(0.1)

    print("Video streaming thread stopped")



def audio_stream_thread():
    """Thread for audio streaming - optimized for performance and stability with WebSocket safety"""
    global audio_stream, audio_streaming_active
    if not PYAUDIO_AVAILABLE or not audio_stream:
        print("Audio not available - exiting audio thread")
        return

    consecutive_errors = 0
    max_consecutive_errors = 5  # Increased tolerance for temporary issues
    websocket_errors = 0
    max_websocket_errors = 3
    buffer_size = 2048  # Match the configured buffer size
    frame_interval = 1.0 / 20.0  # Reduced to 20 FPS to prevent WebSocket congestion
    last_frame_time = time.time()
    frame_skip_counter = 0
    frame_skip_threshold = 1
    max_audio_size = 2048  # Limit audio data size to prevent WebSocket issues

    print("Audio streaming thread started")

    while audio_streaming_active and audio_stream:
        try:
            current_time = time.time()
            if current_time - last_frame_time < frame_interval:
                time.sleep(0.01)  # Prevent busy waiting
                continue

            # Frame skipping for additional CPU relief
            frame_skip_counter += 1
            if frame_skip_counter % (frame_skip_threshold + 1) != 0:
                last_frame_time = current_time
                time.sleep(0.005)
                continue

            # Read audio data with timeout to prevent blocking
            data = audio_stream.read(buffer_size, exception_on_overflow=False)

            if data and len(data) > 0:
                # Limit data size to prevent WebSocket issues
                if len(data) <= max_audio_size:
                    try:
                        # Send raw binary data as hex to reduce processing overhead
                        hex_data = data.hex()
                        # Check hex string size (should be 2 * binary size)
                        if len(hex_data) <= max_audio_size * 2:
                            socketio.emit('audio_data', {'audio': hex_data})
                            consecutive_errors = 0  # Reset error counter on success
                            websocket_errors = 0  # Reset WebSocket error counter on success
                            last_frame_time = current_time
                        else:
                            print(f"Audio hex data too large ({len(hex_data)} chars), skipping")
                            consecutive_errors += 1
                    except Exception as emit_error:
                        websocket_errors += 1
                        consecutive_errors += 1
                        print(f"WebSocket emit error in audio (#{websocket_errors}): {emit_error}")
                        if websocket_errors >= max_websocket_errors:
                            print("Too many WebSocket errors in audio, stopping audio thread to prevent corruption")
                            audio_streaming_active = False
                            break
                else:
                    print(f"Audio data too large ({len(data)} bytes), skipping")
                    consecutive_errors += 1
            else:
                consecutive_errors += 1
                if consecutive_errors >= max_consecutive_errors:
                    print("Audio stream returning empty data, stopping thread")
                    break

            # Longer sleep to reduce CPU usage and WebSocket load
            time.sleep(0.045)  # ~45ms sleep for better stability

        except Exception as e:
            consecutive_errors += 1
            print(f"Error in audio stream (#{consecutive_errors}): {e}")
            if consecutive_errors >= max_consecutive_errors:
                print("Too many consecutive audio errors, stopping audio thread")
                audio_streaming_active = False  # Signal to stop
                break
            time.sleep(0.2)  # Longer pause on error

    print("Audio streaming thread stopped")

def serial_monitor_thread():
    """Thread for serial monitoring - optimized for performance with proper line buffering"""
    global serial_connection, serial_monitoring_active

    if not serial_connection or not serial_connection.is_open:
        print("Serial connection not available - exiting serial thread")
        return

    consecutive_errors = 0
    max_consecutive_errors = 3
    buffer_size = 1024  # Read larger chunks for efficiency
    line_buffer = ""  # Buffer for incomplete lines

    print("Serial monitoring thread started")

    while serial_monitoring_active and serial_connection and serial_connection.is_open:
        try:
            # Use non-blocking read with timeout - prevent eventlet multiple reader error
            if serial_connection.in_waiting > 0:
                # Read available data in chunks
                data = serial_connection.read(min(serial_connection.in_waiting, buffer_size))
                if data:
                    try:
                        # Decode the data and add to line buffer
                        decoded_data = data.decode('utf-8', errors='ignore')
                        line_buffer += decoded_data

                        # Process complete lines
                        while '\n' in line_buffer:
                            line_end = line_buffer.find('\n')
                            complete_line = line_buffer[:line_end].strip()
                            line_buffer = line_buffer[line_end + 1:]  # Remove processed line

                            # Only emit non-empty lines
                            if complete_line:
                                socketio.emit('serial_data', {'data': complete_line})

                        consecutive_errors = 0

                    except UnicodeDecodeError:
                        # If decoding fails, emit as hex and clear buffer
                        if line_buffer:
                            socketio.emit('serial_data', {'data': f'[HEX] {line_buffer.encode().hex()}'})
                            line_buffer = ""
                        consecutive_errors = 0
            else:
                # No data available, small sleep to prevent busy waiting
                time.sleep(0.01)  # Increased sleep to prevent eventlet conflicts

        except Exception as e:
            # Filter out eventlet multiple reader errors - don't log them as they spam the console
            error_msg = str(e)
            if "Second simultaneous read" not in error_msg and "multiple_readers" not in error_msg:
                consecutive_errors += 1
                print(f"Error in serial monitor (#{consecutive_errors}): {e}")
                if consecutive_errors >= max_consecutive_errors:
                    print("Too many consecutive serial errors, stopping serial thread")
                    serial_monitoring_active = False
                    break
            time.sleep(0.1)  # Longer pause on error

    # Send any remaining data in buffer when stopping
    if line_buffer.strip():
        socketio.emit('serial_data', {'data': line_buffer.strip()})

    print("Serial monitoring thread stopped")



def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']
           
def find_usbasp():
    try:
        result=subprocess.run(['lsusb'],capture_output=True, text=True)
        if "16c0:05dc" in result.stdout:
            return True
    except:
        pass
    return False

def detect_avr_chip(port):
    """Detect AVR chip type by trying different signatures"""
    try:
        # Try to read device signature using avrdude
        cmd = ['avrdude', '-c', 'arduino', '-p', 'm328p', '-P', port, '-v']
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)

        if 'Device signature' in result.stderr:
            if '0x1e950f' in result.stderr or 'ATmega328P' in result.stderr:
                return 'atmega328p'
            elif '0x1e930a' in result.stderr or 'ATmega328' in result.stderr:
                return 'atmega328'
            elif '0x1e910a' in result.stderr or 'ATtiny85' in result.stderr:
                return 't85'
            elif '0x1e9206' in result.stderr or 'ATmega168' in result.stderr:
                return 'm168'
            elif '0x1e9307' in result.stderr or 'ATmega8' in result.stderr:
                return 'm8'

        # Fallback: try common AVR chips
        for chip in ['atmega328p', 'atmega328', 't85', 'm168', 'm8']:
            cmd = ['avrdude', '-c', 'arduino', '-p', chip, '-P', port, '-v']
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=3)
            if result.returncode == 0 or 'Device signature' in result.stderr:
                return chip

    except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
        pass

    return 'atmega328p'  # Default fallback

def detect_avr_chip_usbasp():
    """Detect AVR chip type using USBASP programmer"""
    try:
        # First try to read signature with a common chip to get the actual signature
        cmd = ['avrdude', '-c', 'usbasp', '-p', 'm328p', '-v']
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)

        if 'Device signature' in result.stderr:
            signature_line = [line for line in result.stderr.split('\n') if 'Device signature' in line]
            if signature_line:
                signature = signature_line[0].split('=')[1].strip().replace('0x', '').upper()
                # Map signatures to chip types
                signature_map = {
                    '1E950F': 'atmega328p',
                    '1E930A': 'atmega328',
                    '1E910A': 't85',  # ATtiny85
                    '1E9206': 'm168',  # ATmega168
                    '1E9307': 'm8',    # ATmega8
                    '1E9205': 'm8',    # ATmega8A
                }
                return signature_map.get(signature, 'atmega328p')

        # Fallback: try common AVR chips
        for chip in ['atmega328p', 'atmega328', 't85', 'm168', 'm8']:
            cmd = ['avrdude', '-c', 'usbasp', '-p', chip, '-v']
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=3)
            if result.returncode == 0 or 'Device signature' in result.stderr:
                return chip

    except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
        pass

    return 'atmega328p'  # Default fallback

def find_devices():
    global device_cache, device_cache_time, serial_connection

    current_time = time.time()
    # Use cached results if they're still fresh
    if device_cache and (current_time - device_cache_time) < DEVICE_CACHE_TIMEOUT:
        return device_cache

    # Refresh cache
    devices = []
    for port in serial.tools.list_ports.comports():
        if port.vid is not None:
            vid = f"{port.vid:04x}"
            # Skip device detection if serial monitor is using this port
            port_in_use = (serial_connection and
                          hasattr(serial_connection, 'port') and
                          serial_connection.port == port.device and
                          serial_connection.is_open)

            if vid in ARDUINO_IDS:
                if port_in_use:
                    # Port is in use by serial monitor, assume it's an AVR device
                    chip_type = 'atmega328p'  # Default assumption
                    devices.append(('arduino', port.device, f'AVR ({chip_type}) - In Use', chip_type))
                else:
                    chip_type = detect_avr_chip(port.device)
                    devices.append(('arduino', port.device, f'AVR ({chip_type})', chip_type))
            elif vid in ESP32_IDS:
                devices.append(('esp32', port.device, 'ESP32', 'esp32'))
    if find_usbasp():
        usbasp_chip_type = detect_avr_chip_usbasp()
        devices.append(('usbasp','N/A', f'AVR ({usbasp_chip_type})', usbasp_chip_type))

    # Update cache
    device_cache = devices
    device_cache_time = current_time

    return devices

def find_firmware():
    return [f for f in os.listdir('.') if f.endswith(('.hex', '.bin'))]

def upload_firmware(device_type, port, file_path, chip_type='atmega328p'):
    global terminal_output, upload_in_progress

    upload_in_progress = True
    terminal_output = []
    terminal_output.append(f"Starting upload of {file_path} to {device_type.upper()} ({chip_type}) at {port}")

    try:
        if device_type == 'arduino':
            cmd = [
                'avrdude',
                '-p', chip_type,
                '-c', 'arduino',
                '-P', port,
                '-U', f'flash:w:{file_path}:i'
            ]
        elif device_type == 'usbasp':
            cmd = [
                'avrdude',
                '-p', chip_type,
                '-c', 'usbasp',
                '-U', f'flash:w:{file_path}:i'
            ]
        elif device_type == 'esp32':
            cmd = [
                "esptool",
                "--chip", "esp32",
                "--port", port,
                "--baud", ESP_BAUD,
                "--after", "hard_reset",
                "write_flash", "-z", "0x10000", file_path
            ]

        terminal_output.append(f"Executing: {' '.join(cmd)}")

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )

        # Read output line by line
        for line in iter(process.stdout.readline, ''):
            terminal_output.append(line.strip())
            print(line.strip())  # Also print to console

        process.wait()

        if process.returncode == 0:
            terminal_output.append("✅ Upload successful!")
            return True
        else:
            terminal_output.append("❌ Upload failed!")
            return False

    except Exception as e:
        error_msg = f"❌ Error: {str(e)}"
        terminal_output.append(error_msg)
        return False
    finally:
        upload_in_progress = False

# SocketIO event handlers
@socketio.on('start_streaming')
def handle_start_streaming(data):
    global video_streaming_active, audio_streaming_active, video_capture, audio_stream
    try:
        video_requested = data.get('video', False)
        audio_requested = data.get('audio', False)

        print(f"Streaming request: video={video_requested}, audio={audio_requested}")
        print(f"Current state: video_active={video_streaming_active}, audio_active={audio_streaming_active}")

        # Handle video streaming
        if video_requested and not video_streaming_active:
            if initialize_video_capture():
                video_streaming_active = True
                video_thread = threading.Thread(target=video_stream_thread)
                video_thread.daemon = True
                video_thread.start()
                emit('streaming_status', {'type': 'video', 'status': 'started'})
                print("Video streaming thread started")
            else:
                emit('streaming_status', {'type': 'video', 'status': 'error', 'message': 'Could not initialize camera'})
        elif not video_requested and video_streaming_active:
            # Stop video if not requested but currently active
            print("Stopping video streaming...")
            video_streaming_active = False
            emit('streaming_status', {'type': 'video', 'status': 'stopped'})
            print("Video streaming stopped")

        # Handle audio streaming
        if audio_requested and not audio_streaming_active:
            # Start audio if requested and not currently active
            if not audio_stream:
                if initialize_audio_stream():
                    audio_streaming_active = True
                    audio_thread = threading.Thread(target=audio_stream_thread)
                    audio_thread.daemon = True
                    audio_thread.start()
                    emit('streaming_status', {'type': 'audio', 'status': 'started'})
                    print("Audio streaming started")
                else:
                    emit('streaming_status', {'type': 'audio', 'status': 'error', 'message': 'Could not initialize audio - no microphone detected'})
            else:
                # Audio stream exists but thread not active - restart thread
                audio_streaming_active = True
                audio_thread = threading.Thread(target=audio_stream_thread)
                audio_thread.daemon = True
                audio_thread.start()
                emit('streaming_status', {'type': 'audio', 'status': 'started'})
                print("Audio streaming restarted")
        elif not audio_requested and audio_streaming_active:
            # Stop audio if not requested but currently active
            print("Stopping audio streaming...")
            audio_streaming_active = False
            if audio_stream:
                audio_stream.stop_stream()
                audio_stream.close()
                audio_stream = None
            emit('streaming_status', {'type': 'audio', 'status': 'stopped'})
            print("Audio streaming stopped")

    except Exception as e:
        print(f"Error in handle_start_streaming: {e}")
        emit('streaming_status', {'type': 'error', 'message': str(e)})

@socketio.on('stop_streaming')
def handle_stop_streaming():
    global video_streaming_active, audio_streaming_active, video_capture, audio_stream
    video_streaming_active = False
    audio_streaming_active = False

    # Clean up video capture
    if video_capture and video_capture.isOpened():
        try:
            video_capture.release()
        except Exception as e:
            print(f"Error releasing video capture: {e}")
        video_capture = None

    # Clean up audio
    if PYAUDIO_AVAILABLE and audio_stream:
        try:
            audio_stream.stop_stream()
            audio_stream.close()
        except Exception as e:
            print(f"Error stopping audio stream: {e}")
        audio_stream = None

    # NOTE: Serial monitor is NOT stopped by "Stop All" - only by serial monitor controls
    # This prevents accidentally disconnecting serial connections when stopping video/audio

    emit('streaming_status', {'type': 'all', 'status': 'stopped'})

@socketio.on('start_serial_monitor')
def handle_start_serial_monitor(data):
    global serial_monitoring_active, serial_connection
    try:
        port = data.get('port')
        baudrate = data.get('baudrate', 9600)

        if not port:
            emit('serial_status', {'status': 'error', 'message': 'No port specified'})
            return



        # Stop any existing serial monitor
        if serial_connection and serial_connection.is_open:
            serial_monitoring_active = False
            try:
                serial_connection.close()
            except Exception as e:
                print(f"Error closing serial connection: {e}")
            serial_connection = None

        # Initialize serial connection
        if initialize_serial_connection(port, baudrate):
            serial_monitoring_active = True
            serial_thread = threading.Thread(target=serial_monitor_thread)
            serial_thread.daemon = True
            serial_thread.start()
            print(f"Serial monitor thread started for {port}")
            emit('serial_status', {'status': 'started', 'port': port, 'baudrate': baudrate})
        else:
            emit('serial_status', {'status': 'error', 'message': f'Could not open serial port {port}'})

    except Exception as e:
        print(f"Error in handle_start_serial_monitor: {e}")
        emit('serial_status', {'status': 'error', 'message': str(e)})

@socketio.on('stop_serial_monitor')
def handle_stop_serial_monitor():
    global serial_monitoring_active, serial_connection
    serial_monitoring_active = False

    if serial_connection and serial_connection.is_open:
        try:
            serial_connection.close()
        except Exception as e:
            print(f"Error closing serial connection: {e}")
    serial_connection = None

    emit('serial_status', {'status': 'stopped'})

@socketio.on('send_serial_data')
def handle_send_serial_data(data):
    global serial_connection
    try:
        if serial_connection and serial_connection.is_open:
            message = data.get('data', '')
            if message:
                serial_connection.write((message + '\n').encode('utf-8'))
                emit('serial_sent', {'data': message})
    except Exception as e:
        emit('serial_status', {'status': 'error', 'message': str(e)})

@socketio.on('disconnect')
def handle_disconnect():
    """Clean up streaming resources when client disconnects"""
    global video_streaming_active, audio_streaming_active, video_capture, audio_stream, serial_monitoring_active, serial_connection
    print("Client disconnected, cleaning up streaming resources")

    # Stop video streaming
    video_streaming_active = False
    if video_capture and video_capture.isOpened():
        try:
            video_capture.release()
        except Exception as e:
            print(f"Error releasing video capture on disconnect: {e}")
        video_capture = None

    # Stop audio streaming
    audio_streaming_active = False
    if PYAUDIO_AVAILABLE and audio_stream:
        try:
            audio_stream.stop_stream()
            audio_stream.close()
        except Exception as e:
            print(f"Error stopping audio stream on disconnect: {e}")
        audio_stream = None

    # Stop serial monitor on disconnect to prevent stale connections
    serial_monitoring_active = False
    if serial_connection and serial_connection.is_open:
        try:
            serial_connection.close()
        except Exception as e:
            print(f"Error closing serial connection on disconnect: {e}")
        serial_connection = None




@socketio.on('update_oscilloscope_timebase')
def handle_update_oscilloscope_timebase(data):
    try:
        new_timebase = data.get('timebase', 0.001)
        if update_oscilloscope_timebase(new_timebase):
            emit('oscilloscope_timebase_status', {'timebase': oscilloscope_timebase})
        else:
            emit('oscilloscope_timebase_status', {'error': 'Failed to update timebase'})
    except Exception as e:
        emit('oscilloscope_timebase_status', {'error': str(e)})

@socketio.on('update_oscilloscope_vscale')
def handle_update_oscilloscope_vscale(data):
    try:
        new_vscale = data.get('vscale', 1.0)
        if update_oscilloscope_vscale(new_vscale):
            emit('oscilloscope_vscale_status', {'vscale': oscilloscope_vscale})
        else:
            emit('oscilloscope_vscale_status', {'error': 'Failed to update vertical scale'})
    except Exception as e:
        emit('oscilloscope_vscale_status', {'error': str(e)})

@socketio.on('update_oscilloscope_trigger')
def handle_update_oscilloscope_trigger(data):
    try:
        new_level = data.get('level', 0.0)
        if update_oscilloscope_trigger_level(new_level):
            emit('oscilloscope_trigger_status', {'level': oscilloscope_trigger_level})
        else:
            emit('oscilloscope_trigger_status', {'error': 'Failed to update trigger level'})
    except Exception as e:
        emit('oscilloscope_trigger_status', {'error': str(e)})

@app.route('/')
def index():
    devices = find_devices()
    firmware = find_firmware()
    return render_template('index.html', devices=devices, firmware=firmware)

@app.route('/upload', methods=['POST'])
def upload_file():
    global upload_in_progress

    if upload_in_progress:
        return jsonify({'error': 'Upload already in progress'}), 400

    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'firmware')
        file.save(file_path)

        return jsonify({'message': 'File uploaded successfully', 'filename': 'firmware'}), 200

    return jsonify({'error': 'Invalid file type'}), 400

@app.route('/flash', methods=['POST'])
def flash_firmware():
    global upload_in_progress

    if upload_in_progress:
        return jsonify({'error': 'Upload already in progress'}), 400

    device_type = request.form.get('device_type')
    port = request.form.get('port')
    chip_type = request.form.get('chip_type', 'atmega328p')  # Default fallback

    if not device_type or not port:
        return jsonify({'error': 'Device type and port are required'}), 400

    firmware_file = 'firmware'
    if not os.path.exists(firmware_file):
        return jsonify({'error': 'No firmware file found'}), 400

    # Start upload in background thread
    thread = threading.Thread(target=upload_firmware, args=(device_type, port, firmware_file, chip_type))
    thread.daemon = True
    thread.start()

    return jsonify({'message': 'Upload started'}), 200

@app.route('/terminal')
def get_terminal():
    return jsonify({'output': terminal_output, 'in_progress': upload_in_progress})

@app.route('/devices')
def get_devices():
    devices = find_devices()
    return jsonify({'devices': devices})

@app.route('/network')
def get_network_info():
    """Get current network information"""
    try:
        hostname = socket.gethostname()
        # Get IP address
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))  # Connect to Google DNS to get local IP
        ip_address = s.getsockname()[0]
        s.close()

        return jsonify({
            'hostname': hostname,
            'ip_address': ip_address,
            'url_local': f'http://{ip_address}:5000',
            'url_hostname': f'http://{hostname}.local:5000'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500



def find_oscilloscope():
    """Find available oscilloscope devices using pyVISA"""
    if not VISA_AVAILABLE:
        print("PyVISA not available - cannot detect oscilloscopes")
        return None

    try:
        rm = pyvisa.ResourceManager()
        resources = rm.list_resources()

        # Look for oscilloscope-like devices (USB instruments)
        for resource in resources:
            if 'USB' in resource:
                try:
                    # Try to open and identify the device
                    inst = rm.open_resource(resource)
                    # Query device identity
                    identity = inst.query('*IDN?').strip()
                    inst.close()

                    # Check if it's an oscilloscope
                    if any(keyword in identity.upper() for keyword in ['OSCILLOSCOPE', 'SCOPE', 'DSO', 'MSO']):
                        print(f"Found oscilloscope: {identity} at {resource}")
                        return resource, identity
                except Exception as e:
                    print(f"Error identifying device {resource}: {e}")
                    continue

        print("No oscilloscope devices found")
        return None
    except Exception as e:
        print(f"Error scanning for oscilloscopes: {e}")
        return None

def initialize_oscilloscope():
    """Initialize connection to USB oscilloscope"""
    global oscilloscope_resource, oscilloscope_connected, visa_available

    if not VISA_AVAILABLE:
        print("PyVISA not available - oscilloscope features disabled")
        return False

    try:
        # Find oscilloscope
        scope_info = find_oscilloscope()
        if not scope_info:
            print("No oscilloscope found")
            return False

        resource_string, identity = scope_info

        # Initialize VISA resource manager
        rm = pyvisa.ResourceManager()
        oscilloscope_resource = rm.open_resource(resource_string)

        # Configure oscilloscope
        oscilloscope_resource.timeout = 5000  # 5 second timeout

        # Basic setup commands (SCPI - may need adjustment for specific oscilloscope)
        try:
            # Reset to default state
            oscilloscope_resource.write('*RST')
            time.sleep(1)

            # Set up channel 1 (most common)
            oscilloscope_resource.write(':CHANnel1:DISPlay ON')
            oscilloscope_resource.write(':CHANnel1:SCALe 1.0')  # 1V/div
            oscilloscope_resource.write(':CHANnel1:OFFSet 0')   # 0V offset

            # Set timebase
            oscilloscope_resource.write(':TIMebase:SCALe 0.001')  # 1ms/div

            # Set trigger
            oscilloscope_resource.write(':TRIGger:MODE EDGE')
            oscilloscope_resource.write(':TRIGger:EDGE:SOURce CHANnel1')
            oscilloscope_resource.write(':TRIGger:EDGE:LEVel 0')

            # Set acquisition mode
            oscilloscope_resource.write(':ACQuire:TYPE NORMal')

            oscilloscope_connected = True
            visa_available = True
            print(f"Oscilloscope initialized: {identity}")
            return True

        except Exception as e:
            print(f"Error configuring oscilloscope: {e}")
            oscilloscope_resource.close()
            oscilloscope_resource = None
            return False

    except Exception as e:
        print(f"Error initializing oscilloscope: {e}")
        return False

def update_oscilloscope_timebase(new_timebase):
    """Update oscilloscope timebase (horizontal scale)"""
    global oscilloscope_timebase, oscilloscope_resource

    if not oscilloscope_connected or not oscilloscope_resource:
        return False

    try:
        # Validate timebase range (typically 1ns to 50s)
        valid_timebases = [0.000001, 0.000002, 0.000005, 0.00001, 0.00002, 0.00005, 0.0001, 0.0002, 0.0005,
                          0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0]

        # Find closest valid timebase
        closest_timebase = min(valid_timebases, key=lambda x: abs(x - new_timebase))
        oscilloscope_timebase = closest_timebase

        # Send command to oscilloscope
        oscilloscope_resource.write(f':TIMebase:SCALe {oscilloscope_timebase}')
        print(f"Timebase updated to {oscilloscope_timebase}s/div")
        return True

    except Exception as e:
        print(f"Error updating timebase: {e}")
        return False

def update_oscilloscope_vscale(new_vscale):
    """Update oscilloscope vertical scale (amplitude)"""
    global oscilloscope_vscale, oscilloscope_resource

    if not oscilloscope_connected or not oscilloscope_resource:
        return False

    try:
        # Validate vertical scale range (typically 1mV to 10V)
        valid_vscales = [0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0]

        # Find closest valid vertical scale
        closest_vscale = min(valid_vscales, key=lambda x: abs(x - new_vscale))
        oscilloscope_vscale = closest_vscale

        # Send command to oscilloscope
        oscilloscope_resource.write(f':CHANnel{oscilloscope_channel}:SCALe {oscilloscope_vscale}')
        print(f"Vertical scale updated to {oscilloscope_vscale}V/div")
        return True

    except Exception as e:
        print(f"Error updating vertical scale: {e}")
        return False

def update_oscilloscope_trigger_level(new_level):
    """Update oscilloscope trigger level"""
    global oscilloscope_trigger_level, oscilloscope_resource

    if not oscilloscope_connected or not oscilloscope_resource:
        return False

    try:
        oscilloscope_trigger_level = max(-10.0, min(10.0, new_level))  # Limit to reasonable range

        # Send command to oscilloscope
        oscilloscope_resource.write(f':TRIGger:EDGE:LEVel {oscilloscope_trigger_level}')
        print(f"Trigger level updated to {oscilloscope_trigger_level}V")
        return True

    except Exception as e:
        print(f"Error updating trigger level: {e}")
        return False

def calculate_measurements(data_points):
    """Calculate basic measurements from waveform data"""
    if not data_points or len(data_points) < 10:
        return {}

    try:
        # Extract values
        values = [point['value'] for point in data_points]
        times = [point['time'] for point in data_points]

        # Basic statistics
        v_max = max(values)
        v_min = min(values)
        v_pp = v_max - v_min  # Peak-to-peak
        v_avg = sum(values) / len(values)

        # RMS calculation
        v_rms = (sum(v**2 for v in values) / len(values))**0.5

        # Frequency estimation (simple zero-crossing method)
        frequency = 0
        zero_crossings = 0
        prev_value = values[0]

        for value in values[1:]:
            if (prev_value <= 0 and value > 0) or (prev_value >= 0 and value < 0):
                zero_crossings += 1
            prev_value = value

        if zero_crossings > 0:
            time_span = times[-1] - times[0]
            frequency = (zero_crossings / 2) / time_span  # Hz

        # Period calculation
        period = 1.0 / frequency if frequency > 0 else 0

        return {
            'v_max': round(v_max, 3),
            'v_min': round(v_min, 3),
            'v_pp': round(v_pp, 3),
            'v_avg': round(v_avg, 3),
            'v_rms': round(v_rms, 3),
            'frequency': round(frequency, 2),
            'period': round(period * 1000, 2) if period > 0 else 0  # in ms
        }

    except Exception as e:
        print(f"Error calculating measurements: {e}")
        return {}

def read_oscilloscope_data():
    """Read waveform data from the connected oscilloscope"""
    global oscilloscope_resource

    if not oscilloscope_connected or not oscilloscope_resource:
        return None

    try:
        # Check if acquisition is complete
        complete = oscilloscope_resource.query(':ACQuire:COMPlete?').strip()
        if complete != '1':
            return None  # Acquisition not complete

        # Set data format
        oscilloscope_resource.write(':WAVeform:FORMat ASCii')
        oscilloscope_resource.write(':WAVeform:SOURce CHANnel1')

        # Read waveform data
        data_string = oscilloscope_resource.query(':WAVeform:DATA?')
        # Parse the data (format is typically "#<length><data>" or similar)
        if data_string.startswith('#'):
            # Remove header and parse
            header_end = data_string.find('\n')
            if header_end > 0:
                data_part = data_string[header_end:].strip()
                # Split by commas and convert to float
                values = [float(x) for x in data_part.split(',') if x.strip()]

                # Get timing information
                try:
                    x_increment = float(oscilloscope_resource.query(':WAVeform:XINCrement?').strip())
                    x_origin = float(oscilloscope_resource.query(':WAVeform:XORigin?').strip())
                except:
                    x_increment = oscilloscope_timebase / 10.0  # Assume 10 divisions
                    x_origin = 0

                # Convert to our data format
                current_time = time.time()
                data_points = []
                for i, value in enumerate(values):
                    timestamp = current_time + (i * x_increment) + x_origin
                    data_points.append({
                        'time': timestamp,
                        'value': value
                    })

                # Calculate measurements
                measurements = calculate_measurements(data_points)

                return {
                    'data_points': data_points,
                    'measurements': measurements,
                    'timebase': oscilloscope_timebase,
                    'vscale': oscilloscope_vscale,
                    'trigger_level': oscilloscope_trigger_level
                }

        return None

    except Exception as e:
        print(f"Error reading oscilloscope data: {e}")
        return None

def oscilloscope_thread():
    """Thread for oscilloscope data collection using pyVISA USB oscilloscope"""
    global oscilloscope_data, oscilloscope_connected

    print("Oscilloscope thread started")

    # Try to initialize oscilloscope
    if not initialize_oscilloscope():
        print("Failed to initialize oscilloscope - thread will retry periodically")
        oscilloscope_connected = False

    consecutive_errors = 0
    max_consecutive_errors = 5

    while True:
        try:
            if oscilloscope_connected and oscilloscope_resource:
                # Read data from oscilloscope
                data_points = read_oscilloscope_data()

                if data_points:
                    # Update our data buffer
                    oscilloscope_data.extend(data_points['data_points'])

                    # Keep buffer size limited
                    if len(oscilloscope_data) > oscilloscope_buffer_size:
                        oscilloscope_data = oscilloscope_data[-oscilloscope_buffer_size:]

                    # Send data to clients periodically
                    if len(oscilloscope_data) >= 100:  # Send when we have enough data
                        socketio.emit('oscilloscope_data', {
                            'data': oscilloscope_data[-100:],  # Send last 100 samples
                            'measurements': data_points['measurements'],
                            'timebase': data_points['timebase'],
                            'vscale': data_points['vscale'],
                            'trigger_level': data_points['trigger_level'],
                            'connected': True
                        })

                    consecutive_errors = 0
                else:
                    consecutive_errors += 1
                    print(f"Oscilloscope read failed (#{consecutive_errors})")

                # Sleep to avoid overwhelming the oscilloscope (let it control its own timing)
                time.sleep(0.2)  # 200ms delay between reads

            else:
                # Try to reconnect periodically
                if not oscilloscope_connected:
                    print("Attempting to reconnect to oscilloscope...")
                    if initialize_oscilloscope():
                        print("Oscilloscope reconnected successfully")
                        consecutive_errors = 0
                    else:
                        time.sleep(5)  # Wait 5 seconds before retrying
                        continue

        except Exception as e:
            consecutive_errors += 1
            print(f"Error in oscilloscope thread (#{consecutive_errors}): {e}")

            if consecutive_errors >= max_consecutive_errors:
                print("Too many consecutive oscilloscope errors, marking as disconnected")
                oscilloscope_connected = False
                # Send error status to clients
                socketio.emit('oscilloscope_data', {
                    'data': [],
                    'connected': False,
                    'error': str(e)
                })
                time.sleep(5)  # Wait before retrying
                consecutive_errors = 0
            else:
                time.sleep(0.5)

def print_network_info():
    """Print network information on startup"""
    try:
        hostname = socket.gethostname()
        # Get IP address
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))  # Connect to Google DNS to get local IP
        ip_address = s.getsockname()[0]
        s.close()

        print("🌐 Network Information:")
        print(f"   Hostname: {hostname}")
        print(f"   IP Address: {ip_address}")
        print(f"   Local Access: http://{ip_address}:5000")
        print(f"   Hostname Access: http://{hostname}.local:5000")
        print("   (Use hostname access when IP changes with different WiFi)")
        print("")
    except Exception as e:
        print(f"Could not determine network info: {e}")

if __name__ == '__main__':
    print_network_info()

    # Start oscilloscope thread
    oscilloscope_thread_instance = threading.Thread(target=oscilloscope_thread)
    oscilloscope_thread_instance.daemon = True
    oscilloscope_thread_instance.start()

    # Check if we're in production (systemd service)
    is_production = os.environ.get('FLASK_ENV') == 'production'
    print(f"FLASK_ENV: {os.environ.get('FLASK_ENV')}")
    print(f"Is production: {is_production}")

    if is_production:
        print("Starting in PRODUCTION mode with eventlet...")
        # Production: Use eventlet for SocketIO support
        import eventlet
        eventlet.monkey_patch()
        socketio.run(app, host='0.0.0.0', port=5000)
    else:
        print("Starting in DEVELOPMENT mode...")
        # In development, use debug mode
        socketio.run(app, debug=True, host='0.0.0.0', port=5000)

# For Gunicorn deployment (WSGI application for HTTP requests only)
# Note: WebSocket/SocketIO connections require eventlet worker class
application = app  # Use Flask app directly for Gunicorn
