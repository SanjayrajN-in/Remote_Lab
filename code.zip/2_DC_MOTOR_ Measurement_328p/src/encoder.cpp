#include "functions.h"

#define encoder_a PD2
#define encoder_b PD3
// volatile uint16_t count;

void encoder_init() {
    DDRD &= ~(1 << encoder_a);
    DDRD &= ~(1 << encoder_b);
    PORTD |= (1 << encoder_a);
    PORTD |= (1 << encoder_b); 
           
    EICRA |= (1 << ISC01) | (1 << ISC00);
    // EICRA |= (1 << ISC11) | (1 << ISC10);

    EIMSK |= (1 << INT0) ;//| (1 << INT1);
}

