#include "functions.h"

#define IN1 PB0
#define IN2 PD7
#define ENA PD5  // OC0B on ATmega328P

void pwm_init() {
    // Motor direction pins
    DDRB |= (1 << IN1);
    DDRD |= (1 << IN2);
    PORTB &= ~(1 << IN1);
    PORTD &= ~(1 << IN2);
    // PWM enable pin (OC0B)
    DDRD |= (1 << ENA);
    PORTD &= ~(1 << ENA);

    // Fast PWM Mode 7: TOP = OCR0A (WGM02:0 = 7)
    TCCR0A = (1 << WGM01) | (1 << WGM00);
    TCCR0B = (1 << WGM02);

    // Non-inverting on OC0B (COM0B1)
    TCCR0A |= (1 << COM0B1);

    // Prescaler = 8
    TCCR0B |= (1 << CS01);

    // TOP = 99 → ~20 kHz PWM at 16 MHz with prescaler 8
    OCR0A = 99;

    // Initial duty (50%-ish)
    OCR0B = 75;

    // We do not need Timer0 overflow ISR for motor control; keep it off unless needed
    // TIMSK0 |= (1 << TOIE0);
}

void set_duty(uint8_t duty){
    OCR0B = duty;
}

void motor_forward(){
    PORTB |= (1 << IN1);
    PORTD &= ~(1 << IN2);
}
void motor_backward(){
    PORTB &= ~(1 << IN1);
    PORTD |= (1 << IN2);
}
void motor_stop(){
    PORTB &= ~(1 << IN1);
    PORTD &= ~(1 << IN2);
}

void motor_control(){
    // Kept minimal. Drive motor from a slower timer tick or from main.
    motor_forward();
    _delay_ms(3000);
    motor_stop();
    _delay_ms(500);
    motor_backward();
    _delay_ms(3000);
    motor_stop();
    _delay_ms(500);
}