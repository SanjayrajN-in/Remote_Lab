#include "functions.h"

volatile float measured_voltage = 0;  // shared global variable

void ADC_Init(void) {
    ADMUX = (1 << REFS0);  // AVcc reference
    ADCSRA = (1 << ADEN) | (1 << ADIE)               // Enable ADC + interrupt
           | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0); // Prescaler 128
}

void Start_ADC_Conversion(uint8_t channel) {
    ADMUX = (ADMUX & 0xF0) | (channel & 0x0F);  // select ADC channel
    ADCSRA |= (1 << ADSC);                      // start conversion
}

ISR(ADC_vect) {
    uint16_t adc_value = ADC;
    float vout = (adc_value * VREF) / 1023.0;
    measured_voltage = vout * ((R1 + R2) / R2);
}
