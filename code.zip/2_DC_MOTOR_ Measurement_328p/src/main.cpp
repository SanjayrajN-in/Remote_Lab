#include "functions.h"
#include <util/atomic.h>

volatile uint32_t pulses_count = 0;    // pulses counted within the sample interval
volatile int32_t position = 0;         // signed pulse position since power-up
volatile int8_t direction = 0;         // +1 forward/CW, -1 backward/CCW, 0 unknown

char buffer[64];

ISR(TIMER0_COMPA_vect){
    motor_control();
}
// INT0: encoder channel A rising edge
ISR(INT0_vect){
    // sample channel B to decide direction
    uint8_t ch_b = (PIND & (1 << PD3)) ? 1 : 0;

    if(ch_b){
        // depending on wiring, adjust polarity if reversed
        direction = -1;
        position--;
    } else {
        direction = 1;
        position++;
    }
    // increment pulse count for speed measurement
    pulses_count++;
}

// Timer1 Compare A: sample pulses_count every interval (configured in Timer1_init)
ISR(TIMER1_COMPA_vect){
    Start_ADC_Conversion(0); // trigger ADC each 100 ms
    float voltage = measured_voltage;
    uint32_t count = 0;
    // Atomically sample & reset pulses_count
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
        count = pulses_count;
        pulses_count = 0;
    }

    // Compute RPM using integer math.
    // If Timer1 interval is 100 ms (0.1 s): scale = 60 / 0.1 = 600
    // rpm = (count * 600) / PPR
    uint32_t rpm = 0;
    if(PPR > 0){
        rpm = (count * 600UL) / PPR;
    }
    uint16_t angle = (uint32_t)(abs(position) % 2048) * 360UL / 2048;
    // Build message in local buffer; then enqueue for non-blocking UART transmit
    char msg[80];
    char tmp[16];
    strcpy(msg, "PPS: ");
    ultoa(count, tmp, 10);
    strcat(msg, tmp);
    strcat(msg, " | RPM: ");
    ultoa(rpm, tmp, 10);
    strcat(msg, tmp);
    strcat(msg, " | DIR: ");
    strcat(msg, (direction > 0) ? "CW" : (direction < 0 ? "CCW" : "STOP"));
    strcat(msg, " | POS: ");
    // position can be negative; itoa for signed
    itoa((int)position, tmp, 10);
    strcat(msg, tmp);
    strcat(msg, " | angle: ");
    ultoa(angle, tmp, 10);
    strcat(msg, tmp);
    strcat(msg, " | VOL: ");
    dtostrf(voltage, 5, 2, tmp);
    strcat(msg, tmp);
    strcat(msg, "\r\n");
    UART_enqueue_string(msg);
    direction = 0; // reset direction until next pulse
}

int main(void) {
    pwm_init();
    UART_init();
    encoder_init();
    ADC_Init();
    Timer1_init();
    sei(); // enable global interrupts

    // main loop intentionally empty; measurement and reporting are interrupt-driven
    while(1) {
        motor_control();
    }
}