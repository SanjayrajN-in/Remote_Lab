#include "functions.h"

// Simple blocking init + blocking transmit for synchronous use
void UART_init(void) {
    UBRR0H = (uint8_t)(BAUDRATE >> 8);
    UBRR0L = (uint8_t)BAUDRATE;
    UCSR0B = (1 << RXEN0) | (1 << TXEN0); // Enable RX, TX
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);  // 8-bit data
}

void UART_transmit(char data) {
    while (!(UCSR0A & (1 << UDRE0)));
    UDR0 = data;
}

char UART_receive(void) {
    // blocking echo for now
    while (!(UCSR0A & (1 << RXC0)));
    char c = UDR0;
    UART_transmit(c);
    return c;
}

void UART_print(const char* str) {
    while (*str) {
        UART_transmit(*str++);
    }
}

/* Non-blocking TX ring buffer and UDRE ISR.
   Use UART_enqueue_string() from ISRs to queue messages. */
#define TX_BUF_SIZE 128
static volatile char tx_buf[TX_BUF_SIZE];
static volatile uint8_t tx_head = 0;
static volatile uint8_t tx_tail = 0;

void UART_enqueue_string(const char* s){
    // copy as much as fits; drop remainder if full
    while(*s){
        uint8_t next = (uint8_t)(tx_head + 1);
        if(next >= TX_BUF_SIZE) next = 0;
        if(next == tx_tail) break; // buffer full
        tx_buf[tx_head] = *s++;
        tx_head = next;
    }
    // Enable UDRE interrupt to kick transmission
    UCSR0B |= (1 << UDRIE0);
}

ISR(USART_UDRE_vect){
    if(tx_tail == tx_head){
        // buffer empty: disable UDRE interrupt
        UCSR0B &= ~(1 << UDRIE0);
        return;
    }
    UDR0 = tx_buf[tx_tail];
    tx_tail++;
    if(tx_tail >= TX_BUF_SIZE) tx_tail = 0;
}

void Timer1_init(void){
    // Configure Timer1 for CTC mode and a 100 ms interrupt interval.
    // Assumes F_CPU = 16 MHz (see functions.h).
    // Using prescaler = 64 -> tick = F_CPU/64 = 250000 Hz
    // For 100 ms interval: OCR1A = tick * 0.1 - 1 = 250000 * 0.1 - 1 = 25000 - 1
    TCCR1A = 0;                     // Normal port operation
    TCCR1B = 0;                     // Clear, then set required bits
    TCCR1B |= (1 << WGM12);         // CTC mode (WGM12 = 1)
    OCR1A = 25000 - 1;              // 100 ms at 16MHz / 64
    TIMSK1 |= (1 << OCIE1A);        // Enable Timer1 Compare A interrupt
    TCCR1B |= (1 << CS11) | (1 << CS10); // Prescaler 64
}