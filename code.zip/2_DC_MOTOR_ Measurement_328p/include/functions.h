#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#define F_CPU 16000000UL

// ==== Configuration ====
#define BAUD 9600
#define BAUDRATE ((F_CPU / (16UL * BAUD)) - 1)

#define PPR 2048UL   // pulses per revolution (adjust for your encoder)
#define VREF 5.0            // ADC reference voltage
#define R1 10000.0          // 10kΩ resistor
#define R2 4700.0           // 4.7kΩ resistor

extern volatile float measured_voltage;
//-------HEADER FILES-------
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

//------PWM-------------
void pwm_init(void);
void set_duty(uint8_t duty);
void motor_forward(void);
void motor_backward(void);
void motor_stop(void);
void motor_control(void);

// encoder
void encoder_init(void);

//------UART------------
void UART_init(void);
void UART_transmit(char data);
char UART_receive(void);
void UART_print(const char* str);

// Non-blocking enqueue for ISR-safe prints
void UART_enqueue_string(const char* s);

// Timer1 (sampling timer)
void Timer1_init(void);

void ADC_Init(void);
void Start_ADC_Conversion(uint8_t channel);
#endif